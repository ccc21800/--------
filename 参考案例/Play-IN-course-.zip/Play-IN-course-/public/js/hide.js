document.addEventListener('DOMContentLoaded', function() {
  let errorCount = 0;
  window.onload = function() {
    const urlParams = new URLSearchParams(window.location.search);
    const error = urlParams.get('error');
    if (error === 'true') {
      errorCount++;
      if (errorCount === 3) {
        document.getElementById('hint').classList.remove('d-none');
      } else {
        alert('密码错了呦!');
      }
    }
  }
  });