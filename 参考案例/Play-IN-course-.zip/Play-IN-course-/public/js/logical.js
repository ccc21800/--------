document.addEventListener('DOMContentLoaded', function () {
  const sidCells = document.querySelectorAll('.sid');
  sidCells.forEach(function (cell) {
    cell.addEventListener('click', function (event) {
      event.preventDefault();
      const sid = this.dataset.sid;
      window.location.href = `/student_details/${sid}`;
    });
  });
});

document.querySelectorAll('.query-form').forEach(form => {
  form.addEventListener('submit', function (event) {
    event.preventDefault();
    const sid = this.querySelector('.sid').dataset.sid;
    const homeworkNum = this.querySelector('.select-box').value;
    fetch(`/query-homework?sid=${sid}&homeworkNum=${homeworkNum}`)
      .then(response => response.json())
      .then(data => {
        const scoresContainer = this.querySelector('.homework-scores');
        scoresContainer.textContent = `第${homeworkNum}次作业成绩：${data.score}`;
      })
      .catch(error => {
        console.error('Error fetching homework score:', error);
      });
  });
});

document.addEventListener('DOMContentLoaded', function () {
  let slideIndex = 0;
  showSlides();

  function showSlides() {
    let i;
    let slides = document.querySelectorAll(".mySlides");
    if (slides.length === 0) {
      return;
    }

    for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex > slides.length) { slideIndex = 1 }
    slides[slideIndex - 1].style.display = "block";
    setTimeout(showSlides, 5000);
  }
});

document.addEventListener('DOMContentLoaded', function () {
  const productContainer = document.querySelector('.product-container');
  const prevBtn = document.querySelector('.prev-btn');
  const nextBtn = document.querySelector('.next-btn');
  const currentPageSpan = document.querySelector('.current-page');

  let currentPage = 1;
  const pageSize = 15;

  function renderProducts(products) {
    productContainer.innerHTML = '';
    products.forEach(product => {
      const card = document.createElement('div');
      card.classList.add('mail_card');
      card.dataset.title = product.title;
      card.dataset.price = product.price;
      card.dataset.inventory = product.inventory;
      card.dataset.coname = product.coname || product.title;
      card.innerHTML = `
        <img class="mail_card_image" src="${product.imagePath}">
        <div class="mail_card_title">${product.title}</div>
        <div class="mail_card_info">
          <img src="/images/logo.png">
          <div class="mail_card_info_price" data-price="${product.price}">${product.price}</div>
          <div class="mail_card_info_count">库存 ${product.inventory}</div>
        </div>
      `;

      card.addEventListener('click', () => {
        const coname = card.dataset.coname;
        const title = card.dataset.title;
        const price = card.dataset.price;
        const inventory = card.dataset.inventory;
        const imagePath = card.querySelector('.mail_card_image').src;
        const modal = showProductModal(coname, title, price, inventory, imagePath);
        document.body.appendChild(modal);
      });

      productContainer.appendChild(card);
    });
  }

  function fetchProducts(page) {
    fetch(`/token_mail_data?page=${page}`)
      .then(response => response.json())
      .then(data => {
        renderProducts(data.products);
        currentPage = data.currentPage;
        currentPageSpan.textContent = currentPage;
        prevBtn.disabled = currentPage === 1;
        nextBtn.disabled = currentPage === data.totalPages;
      })
      .catch(error => {
        console.error('Error fetching products:', error);
      });
  }

  fetchProducts(1);

  prevBtn.addEventListener('click', () => {
    if (currentPage > 1) {
      fetchProducts(currentPage - 1);
    }
  });

  nextBtn.addEventListener('click', () => {
    fetchProducts(currentPage + 1);
  });

  function showProductModal(coname, title, price, inventory, imagePath) {
    let modal = document.createElement('div');
    modal.classList.add('product-modal');
    modal.innerHTML = `
      <div class="modal-content">
        <span class="close-btn">&times;</span>
        <img class="modal-image" src="${imagePath}">
        <h2 class="modal-title">${title}</h2>
        <p class="modal-price">价格: ${price}</p>
        <p class="modal-inventory">库存: ${inventory}</p>
        <div class="modal-details"></div>
        <button class="exchange-btn">兑换</button>
      </div>
    `;

    fetch(`/product/${coname}`)
      .then(response => response.json())
      .then(data => {
        if (data.error) {
          console.error(data.error);
        } else {
          const detailsContainer = modal.querySelector('.modal-details');
          detailsContainer.innerHTML = `<p>${data.codetails}</p>`;
        }
      })
      .catch(error => {
        console.error('Error fetching product details:', error);
      });

    const closeBtn = modal.querySelector('.close-btn');
    closeBtn.addEventListener('click', () => {
      modal.remove();
    });

    window.addEventListener('click', (event) => {
      if (event.target === modal) {
        modal.remove();
      }
    });

    const exchangeBtn = modal.querySelector('.exchange-btn');
    exchangeBtn.addEventListener('click', () => {
      fetch('/student_details', { credentials: 'same-origin' })
        .then(response => response.json())
        .then(data => {
          const studentTokens = data.student.stoken;
          if (studentTokens >= price) {
            fetch('/exchange', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({ coname, price })
            })
              .then(response => response.json())
              .then(data => {
                if (data.success) {
                  alert('兑换成功,请等待老师确认');
                } else {
                  alert('兑换失败: ' + data.error);
                }
              })
              .catch(error => {
                console.error('Error exchanging product:', error);
                alert('兑换失败,请重试');
              });
          } else {
            alert('积分余额不足,无法兑换5.afraid');
          }
        })
        .catch(error => {
          console.error('Error fetching student details:', error);
          alert('获取学生信息失败,请重试');
        });
    });

    return modal;
  }
});
window.addEventListener('DOMContentLoaded', () => {
let clickCount = 0;
const images = document.querySelectorAll('img[src="images/logo.png"]');

images.forEach(img => {
  img.addEventListener('click', () => {
    clickCount++;
    if (clickCount === 18) {  //在这里更改点击次数
      window.location.href = '/hide';
    }
  });
});
});

window.addEventListener('DOMContentLoaded', () => {
  const hiddenText = '<!-- 这里有一个小彩蛋你可以尝试点击几次logo4.talk -->';
  console.log('隐藏的文本:');
  console.log(hiddenText);
});