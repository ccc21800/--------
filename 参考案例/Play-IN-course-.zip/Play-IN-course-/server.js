const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const app = express();
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const config = require('./config');
const routes = require('./routes');
const SHA256 = require('crypto-js/sha256');

app.use(session({ secret: '123456', resave: false, saveUninitialized: true, cookie: { maxAge: 24 * 60 * 60 * 1000 } }));
app.set('view engine', 'pug');
app.use(express.static('public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/', routes);
app.use('/exam', express.static(path.join(__dirname, 'exam')));

const pool = mysql.createPool(config.database);
console.log('Connection Pool:', pool);

app.post('/login', (req, res) => {
    console.log('Request Body:', req.body);
    const username = req.body.sid;
    const password = req.body.password;
    console.log('Username:', username);
    console.log('Password:', password);

    // 先查询学生表
    pool.query('SELECT sid AS id, sname AS name, spassword AS password, scid AS class, 0 AS power FROM students WHERE sid = ? OR sname = ?', [username, username], (err, studentResults) => {
        if (err) {
            console.error('Error executing student query:', err);
            return res.status(500).send('Internal Server Error');
        }

        console.log('Student Results:', studentResults);

        // 如果学生表有结果,进行密码验证
        if (studentResults.length > 0) {
            console.log(studentResults[0]);
            const storedPassword = studentResults[0].password;
            const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');

            if (storedPassword === hashedPassword) {
                // 密码正确,处理会话数据
                req.session.uid = studentResults[0].id;
                req.session.sid = studentResults[0].id;
                req.session.name = studentResults[0].name;
                req.session.class = studentResults[0].class;
                req.session.power = studentResults[0].power;
                console.log('Session Data:', req.session);
                return res.redirect('/?session=' + req.session);
            } else {
                req.session.destroy();
                return res.render('login', { error: '密码错误' });
            }
        } else {
            // 如果学生表没有结果,查询教师表
            pool.query('SELECT tid AS id, tname AS name, tpassword AS password, tclass AS class, 1 AS power FROM teachers WHERE tid = ? OR tname = ?', [username, username], (err, teacherResults) => {
                if (err) {
                    console.error('Error executing teacher query:', err);
                    return res.status(500).send('Internal Server Error');
                }
                console.log('Teacher Results:', teacherResults);
                if (teacherResults.length > 0) {
                    const storedPassword = teacherResults[0].password;
                    const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');

                    if (storedPassword === hashedPassword) {
                        req.session.uid = teacherResults[0].id;
                        req.session.sid = teacherResults[0].id;
                        req.session.name = teacherResults[0].name;
                        req.session.class = teacherResults[0].class;
                        req.session.power = teacherResults[0].power;
                        console.log('Session Data:', req.session);
                        return res.redirect('/?session=' + req.session);
                    } else {
                        req.session.destroy();
                        return res.render('login', { error: '密码错误' });
                    }
                } else {
                    req.session.destroy();
                    return res.render('login', { error: '用户不存在6.story' });
                }
            });
        }
    });
});
// 签到路由
app.post('/checkin', (req, res) => {
    const currentTime = new Date();
    const sid = req.session.sid;
  
    // 检查用户是否登录
    if (!sid) {
      return res.status(401).json({ error: '您尚未登录' });
    }
  
    // 获取当前日期
    const currentDate = new Date().toISOString().slice(0, 10);
  
    // 检查用户今天是否已经签到过
    pool.query('SELECT * FROM logs WHERE sid = ? AND DATE(ltime) = ?', [sid, currentDate], (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: '内部服务器错误' });
      }
  
      if (results.length > 0) {
        return res.status(400).json({ error: '您今天已经签到过了' });
      }
  
      // 随机生成1~5之间的积分
      const tokens = Math.floor(Math.random() * 5) + 1;
  
      // 更新积分到数据库
      pool.query('UPDATE students SET stoken = stoken + ? WHERE sid = ?', [tokens, sid], (err, result) => {
        if (err) {
          console.error(err);
          return res.status(500).json({ error: '内部服务器错误' });
        }
  
        // 插入签到记录到日志表
        pool.query('INSERT INTO logs (sid, linfo, ltime, ltype) VALUES (?, ?, ?, 3)', [sid, `获得${tokens}积分`, currentTime], (err, result) => {
          if (err) {
            console.error(err);
            return res.status(500).json({ error: '内部服务器错误' });
          }
  
          res.status(200).json({ success: true, message: `签到成功,获得${tokens}积分` });
        });
      });
    });
  });
app.post('/changePassword', (req, res) => {
    const sid = req.session.sid;
    const oldPassword = req.body.oldPassword;
    const newPassword = req.body.newPassword;
    pool.query('SELECT * FROM students WHERE sid = ?', [sid], (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Internal Server Error');
        }
        if (results.length > 0) {
            if (results[0].spassword === oldPassword) {
                pool.query('UPDATE students SET spassword = ? WHERE sid = ?', [newPassword, sid], (err, result) => {
                    if (err) {
                        console.error(err);
                        return res.status(500).send('Internal Server Error');
                    }
                    res.redirect(`/student_details/${sid}`);
                });
            } else {
                res.render('student_details', { student: results[0], error: '原密码错误' });
            }
        } else {
            res.redirect('/login');
        }
    });
});

app.get('/', (req, res) => {
    console.log("/ 被访问")
    console.log("req.session:", req.session)
    if (req.session) {
      const { uid, power } = req.session;
  
      if (power === 1) {
        pool.query('SELECT s.*, c.cname FROM students s JOIN classes c ON s.scid = c.cid ORDER BY s.sname ASC', (err, students) => {
          if (err) {
            console.error(err);
            return res.status(500).send('Internal Server Error');
          }
          pool.query('SELECT tid AS id, tname AS name, tclass AS class, 1 AS power FROM teachers WHERE tid = ?', [uid], (err, teacherResults) => {
            if (err) {
              console.error(err);
              return res.status(500).send('Internal Server Error');
            }
            if (teacherResults.length > 0) {
              const teacher = teacherResults[0];
              pool.query('SELECT s.sname, c.coname, e.price FROM exchange_logs e JOIN students s ON e.sid = s.sid JOIN commodities c ON e.coname = c.coname', (err, exchangeLogs) => {
                if (err) {
                  console.error(err);
                  return res.status(500).send('Internal Server Error');
                }
                res.render('index', { teacher, students, exchangeLogs, req });
              });
            } else {
              res.redirect('/login');
            }
          });
        });
      } else {
        pool.query('SELECT s.*, c.cname FROM students s JOIN classes c ON s.scid = c.cid WHERE s.sid = ?', [uid], (err, results) => {
          if (err) {
            console.error(err);
            return res.status(500).send('Internal Server Error');
          }
          if (results.length > 0) {
            const student = results[0];
            pool.query('SELECT s.*, c.cname FROM students s JOIN classes c ON s.scid = c.cid WHERE s.scid = ? ORDER BY s.sname ASC', [student.scid], (err, students) => {
              if (err) {
                console.error(err);
                return res.status(500).send('Internal Server Error');
              }
              res.render('index', { student, students, req });
            });
          } else {
            res.redirect('/login');
          }
        });
      }
    } else {
      res.redirect('/login');
    }
  });

app.get('/student_details/:sid', async (req, res) => {
    const sid = req.params.sid;
    const query = `
    SELECT s.sid, s.sname, c.cname, s.savatar, s.stoken, s.sgithub, s.shomework, s.sequipments, s.sprops, s.scommodities
    FROM students s
    JOIN classes c ON s.scid = c.cid
    WHERE s.sid = ?
  `;

    pool.query(query, [sid], (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Internal Server Error');
        }
        const student = results[0];
        if (student) {
            res.render('student_details', { student });
        } else {
            res.status(404).send('学生不存在');
        }
    });
});

app.get('/student_details', (req, res) => {
    const sid = req.session.sid;
    const query = `
      SELECT s.sid, s.sname, c.cname, s.savatar, s.stoken, s.sgithub, s.shomework, s.sequipments, s.sprops, s.scommodities
      FROM students s
      JOIN classes c ON s.scid = c.cid
      WHERE s.sid = ?
    `;
  
    pool.query(query, [sid], (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).send('Internal Server Error');
      }
      const student = results[0];
      if (student) {
        res.json({ student });
      } else {
        res.status(404).send('学生不存在');
      }
    });
  });

app.get('/teacher_details/:tid', (req, res) => {
    const tid = req.params.tid;
    pool.query('SELECT * FROM teachers WHERE tid = ?', [tid], (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Internal Server Error');
        }
        if (results.length > 0) {
            const teacher = results[0];
            res.render('teacher_details', { teacher });
        } else {
            res.redirect('/login');
        }
    });
});




const pageSize = 15;

app.get('/token_mail', (req, res) => {
    res.render('token_mail', {
        title: '',
    });
});

app.get('/token_mail_data', (req, res) => {
    const page = req.query.page ? parseInt(req.query.page) : 1;
    const startIndex = (page - 1) * pageSize;
    const endIndex = startIndex + pageSize;
  
    // 先获取总记录数
    pool.query('SELECT COUNT(*) AS total FROM commodities', (err, countResult) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'Internal Server Error' });
      }
  
      const totalRecords = countResult[0].total;
      const totalPages = Math.ceil(totalRecords / pageSize);
  
      // 然后获取当前页的商品数据
      pool.query('SELECT coname AS title, coimage AS imagePath, coprice AS price, coamount AS inventory FROM commodities LIMIT ?, ?', [startIndex, pageSize], (err, results) => {
        if (err) {
          console.error(err);
          return res.status(500).json({ error: 'Internal Server Error' });
        }
  
        res.json({
          products: results,
          currentPage: page,
          totalPages
        });
      });
    });
  });

  app.get('/product/:coname', (req, res) => {
    const coname = req.params.coname;
    pool.query('SELECT codetails FROM commodities WHERE coname = ?', [coname], (err, result) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'Internal Server Error' });
      }
      if (result.length > 0) {
        const codetails = result[0].codetails;
        res.json({ codetails });
      } else {
        res.status(404).json({ error: 'Product not found' });
      }
    });
  });
  app.post('/exchange', (req, res) => {
    const { coname, price } = req.body;
    const sid = req.session.sid;
  
    // 检查用户是否登录
    if (!sid) {
      return res.status(401).json({ error: '您尚未登录' });
    }
  
    // 检查学生积分是否足够
    pool.query('SELECT stoken FROM students WHERE sid = ?', [sid], (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: '内部服务器错误' });
      }
  
      const studentTokens = results[0].stoken;
      if (studentTokens >= price) {
        // 扣除学生积分
        pool.query('UPDATE students SET stoken = stoken - ? WHERE sid = ?', [price, sid], (err, result) => {
          if (err) {
            console.error(err);
            return res.status(500).json({ error: '内部服务器错误' });
          }
  
          // 将兑换信息存入数据库
          pool.query('INSERT INTO exchange_logs (sid, coname, price) VALUES (?, ?, ?)', [sid, coname, price], (err, result) => {
            if (err) {
              console.error(err);
              return res.status(500).json({ error: '内部服务器错误' });
            }
  
            // 返回成功响应
            res.json({ success: true });
          });
        });
      } else {
        res.status(400).json({ error: '积分余额不足' });
      }
    });
  });
  
app.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/');
});

app.get('/index', (req, res) => {
    console.log("/index 被访问")
    res.render('index')
});

app.get('/login', (req, res) => {
    res.render('login');
});

app.get('/news', (req, res) => {
    res.render('news');
});

app.get('/images', (req, res) => {
    res.render('images');
});

app.get('/js', (req, res) => {
    res.render('js');
});
app.post('/hide', (req, res) => {
  const password = req.body.password;
  const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');

  pool.query('SELECT * FROM hide WHERE hidepassword = ?', [hashedPassword], (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Internal Server Error');
    }

    if (results.length > 0) {
      
      res.redirect('/secret');
    } else {
      
      res.redirect('/hide?error=true');
    }
  });
});
app.get('/hide', (req, res) => {
  res.render('hide');
});
app.get('/secret', (req, res) => {
  res.render('secret');
});


app.post('/secret', (req, res) => {
  const passwords = [
    req.body.password1,
    req.body.password2,
    req.body.password3,
    req.body.password4,
    req.body.password5,
    req.body.password6,
    req.body.password7,
    req.body.password8,
    req.body.password9,
    req.body.password10,
    req.body.password11,
    req.body.password12
  ];

  const hashedPasswords = passwords.map(password => SHA256(password).toString());

  pool.query('SELECT MP1, MP2, MP3, MP4, MP5, MP6, MP7, MP8, MP9, MP10, MP11, MP12 FROM hide', (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Internal Server Error');
    }

    const hidePasswords = results[0];
    const storedPasswords = Object.values(hidePasswords);

    if (hashedPasswords.every((hashedPassword, index) => hashedPassword === storedPasswords[index])) {
      res.render('closet');
    } else {
      res.render('secret', { error: '密码错误' });
    }
  });
});
app.post('/end', (req, res) => {
  const password = req.body.password;
  const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');

  pool.query('SELECT * FROM hide WHERE closetpassword = ?', [hashedPassword], (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Internal Server Error');
    }

    if (results.length > 0) {
      
      res.redirect('/end');
    } else {
      
      res.redirect('/closet?error=true');
    }
  });
})
app.get('/closet', (req, res) => {
  res.render('closet');
});

const port = process.env.PORT || 80; 
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
