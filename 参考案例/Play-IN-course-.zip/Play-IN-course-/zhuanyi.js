const crypto = require('crypto');
const mysql = require('mysql');

const config = require('./config');

const pool = mysql.createPool(config.database);

// 从数据库获取明文密码
pool.query('SELECT closetpassword, MP1, MP2, MP3, MP4, MP5, MP6, MP7, MP8, MP9, MP10, MP11, MP12 FROM hide', (err, results) => {
  if (err) {
    console.error('Error querying database:', err);
    return;
  }

  if (results.length === 0) {
    console.log('No data found in the hide table.');
    return;
  }

  const row = results[0];
  const hashedPasswords = {};

  // 对每个密码字段进行SHA256哈希计算
  hashedPasswords.MP1 = crypto.createHash('sha256').update(row.closetpassword).digest('hex');
  hashedPasswords.MP1 = crypto.createHash('sha256').update(row.MP1).digest('hex');
  hashedPasswords.MP2 = crypto.createHash('sha256').update(row.MP2).digest('hex');
  hashedPasswords.MP3 = crypto.createHash('sha256').update(row.MP3).digest('hex');
  hashedPasswords.MP4 = crypto.createHash('sha256').update(row.MP4).digest('hex');
  hashedPasswords.MP5 = crypto.createHash('sha256').update(row.MP5).digest('hex');
  hashedPasswords.MP6 = crypto.createHash('sha256').update(row.MP6).digest('hex');
  hashedPasswords.MP7 = crypto.createHash('sha256').update(row.MP7).digest('hex');
  hashedPasswords.MP8 = crypto.createHash('sha256').update(row.MP8).digest('hex');
  hashedPasswords.MP9 = crypto.createHash('sha256').update(row.MP9).digest('hex');
  hashedPasswords.MP10 = crypto.createHash('sha256').update(row.MP10).digest('hex');
  hashedPasswords.MP11 = crypto.createHash('sha256').update(row.MP11).digest('hex');
  hashedPasswords.MP12 = crypto.createHash('sha256').update(row.MP12).digest('hex');

  // 打印哈希值
  console.log('Hashed Passwords:', hashedPasswords);

  // 更新数据库
  const updateQueries = [];
  for (const field in hashedPasswords) {
    const value = hashedPasswords[field].replace(/'/g, "\\'"); // 替换单引号
    updateQueries.push(`UPDATE hide SET ${field} = '${value}' WHERE 1`);
  }

  // 每次执行一个更新查询
  const executeQuery = (index) => {
    if (index >= updateQueries.length) {
      console.log('Database updated successfully.');
      pool.end(); // 关闭连接池
      return;
    }

    const query = updateQueries[index];
    pool.query(query, (err, results) => {
      if (err) {
        console.error(`Error updating ${query}:`, err);
        pool.end(); // 关闭连接池
        return;
      }
      executeQuery(index + 1); // 执行下一个查询
    });
  };

  executeQuery(0); // 开始执行更新查询
});