const fs = require('fs');  
const path = require('path');  
  
// 图片文件夹路径  
const imageFolderPath = './public/images/Commodities';  
// 新的图片名称前缀  
const newNamePrefix = '';  
// 图片文件扩展名  
const imageExtension = '.png';  
  
// 读取文件夹中的文件  
fs.readdir(imageFolderPath, (err, files) => {  
  if (err) {  
    console.error("无法读取文件夹: ", err);  
    return;  
  }  
  
  // 过滤出 .jpg 文件  
  const imageFiles = files.filter(file => path.extname(file).toLowerCase() === imageExtension);  
  
  // 对图片文件进行编号  
  imageFiles.sort().forEach((file, index) => {  
    // 构建新的文件名  
    const newFileName = `${newNamePrefix}${index + 1}${imageExtension}`;  
    // 构建原文件路径和新文件路径  
    const oldFilePath = path.join(imageFolderPath, file);  
    const newFilePath = path.join(imageFolderPath, newFileName);  
  
    // 重命名文件  
    fs.rename(oldFilePath, newFilePath, (err) => {  
      if (err) {  
        console.error(`重命名文件 ${oldFilePath} 到 ${newFilePath} 时出错: `, err);  
      } else {  
        console.log(`文件 ${oldFilePath} 已重命名为 ${newFilePath}`);  
      }  
    });  
  });  
});