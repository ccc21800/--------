  function checkin() {
    fetch('/checkin', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({})
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        alert(data.message);
        updateTokens(data.tokens);
        setTimeout(refreshPage, 2000);
      } else {
        alert(data.error);
      }
    })
    .catch(error => {
      console.error('Error:', error);
      alert('发生错误,请重试');
    });
  }

  function updateTokens(tokens) {
    const tokenElement = document.getElementById('student-token');
    tokenElement.textContent = parseInt(tokenElement.textContent) + tokens;
  }
  function refreshPage() {
    location.reload();
  }