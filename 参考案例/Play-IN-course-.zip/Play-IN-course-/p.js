const mysql = require('mysql');  
const fs = require('fs');  
const path = require('path');  
const { promisify } = require('util');  
  
// MySQL数据库连接配置  
const connection = mysql.createConnection({  
  host: '',  
  user: 'your_username',  
  password: 'your_password',  
  database: 'your_database'  
}); 
  
// 将连接方法转换为Promise  
const query = promisify(connection.query).bind(connection);  
  
// 遍历图片文件夹中的文件，并将它们插入到数据库中  
async function insertImagesToDatabase(folderPath) {  
  try {  
    const files = await promisify(fs.readdir)(folderPath);  
  
    for (const file of files) {  
      const filePath = path.join(folderPath, file);  
      const stats = await promisify(fs.stat)(filePath);  
  
      if (stats.isFile()) {  
        // 读取文件内容  
        const fileContent = await promisify(fs.readFile)(filePath);  
        // 将文件内容转换为Base64编码  
        const base64Data = fileContent.toString('base64');  
  
        // 插入到数据库  
        const sql = 'INSERT INTO images (image_name, image_base64) VALUES (?, ?)';  
        await query(sql, [file, base64Data]);  
  
        console.log(`Inserted ${file}`);  
      }  
    }  
  
    console.log('All images have been inserted into the database.');  
  } catch (err) {  
    console.error('Error inserting images into database:', err);  
  } finally {  
    // 关闭数据库连接  
    connection.end();  
  }  
}  
  
// 调用函数并传入图片文件夹路径  
insertImagesToDatabase('path/to/your/tokenimg/folder').catch(console.error);