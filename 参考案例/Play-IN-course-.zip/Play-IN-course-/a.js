const crypto = require('crypto-js');

// 要转换的明文密码列表
const passwords = [
  '15678432',
  // 添加更多密码...
];

// 将明文密码转换为 SHA256 哈希值
const hashedPasswords = passwords.map(password => crypto.SHA256(password).toString());

console.log('明文密码:\n', passwords);
console.log('\nSHA256 哈希值:\n', hashedPasswords);