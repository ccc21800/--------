module.exports = {
  database: {
    host: 'rm-wz9534kakaqe7oegszo.mysql.rds.aliyuncs.com',
    user: 'root',
    password: 'wmzcl1gpt@@@',
    database: 'course',
  }
};