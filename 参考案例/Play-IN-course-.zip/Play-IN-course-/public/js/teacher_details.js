$(document).ready(function() {
    // 处理导航链接点击事件
    $('.nav-link').click(function(e) {
      e.preventDefault();
      const option = $(this).data('option');
      const tid = $(this).data('tid');
      renderContent(option, tid);
    });
  
    // 渲染内容区域
    function renderContent(option,tid) {
      const contentArea = $('.content-area');
      contentArea.empty();
  
      switch (option) {
        case 'personal-info':  
          const url = `/teacher/${tid}/personal-info`; 
                $.get(url)  
                .done(function(data) {    
                    contentArea.html(data); 
                })    
                .fail(function(jqXHR, textStatus, errorThrown) {    
                    // 处理 AJAX 请求失败的情况    
                    contentArea.html('<p>加载内容失败: ' + textStatus + '</p>');    
                });    
                break; 
          // contentArea.append('<h2>个人信息</h2>');
          // break;
        case 'product-management':
          const productUrl = '/product-management'; 
              $.get(productUrl)
                .done(function(data) {
                  contentArea.html(data);
                })
                .fail(function(jqXHR, textStatus, errorThrown) {
                  contentArea.html('<p>加载内容失败: ' + textStatus + '</p>');
                });
          break;
        case 'permission-management':
          const permissionUrl = '/permissions'; // 或 '/permission-management'
          $.get(permissionUrl)
            .done(function(data) {
              contentArea.html(data);
            })
            .fail(function(jqXHR, textStatus, errorThrown) {
              contentArea.html(`<p>加载内容失败: ${textStatus}</p>`);
            });
            break;
        case 'student-management':
              const studentUrl = '/student-management';
              $.get(studentUrl)
                .done(function(data) {
                  contentArea.html(data);
                })
                .fail(function(jqXHR, textStatus, errorThrown) {
                  contentArea.html('<p>加载内容失败: ' + textStatus + '</p>');
                });
              break;
        default:
          contentArea.append('<p>无效的选项。</p>');
      }
    }
    const updatePermissionForms = document.querySelectorAll('form[action^="/permissions/"]');

    updatePermissionForms.forEach(form => {
      form.addEventListener('submit', async (event) => {
        event.preventDefault();

        const sid = form.action.split('/').pop();
        const spower = form.querySelector('input[name="spower"]').value;

        if (spower < 0 || spower > 2 || !Number.isInteger(parseFloat(spower))) {
          alert('权限级别只能输入 0、1 或 2');
          return;
        }

        try {
          const response = await fetch(`/permissions/${sid}`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({ spower })
          });

          if (response.ok) {
            // 权限更新成功,可以在这里进行其他操作,如重新加载页面
            console.log('权限更新成功');
          } else {
            console.error('权限更新失败');
          }
        } catch (error) {
          console.error('发生错误:', error);
        }
      });
    });
  });
  