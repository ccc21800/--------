const mysql = require('mysql');
const crypto = require('crypto');

// 创建数据库连接
const connection = mysql.createConnection({
  host: 'rm-wz9534kakaqe7oegszo.mysql.rds.aliyuncs.com',
  user: 'root',
  password: 'wmzcl1gpt@@@',
  database: 'course',
});

// 连接数据库
connection.connect(err => {
  if (err) {
    console.error('Error connecting to database: ' + err.stack);
    return;
  }
  console.log('Connected to database');
  
  // 查询所有用户
  connection.query('SELECT sid, spassword FROM students', (err, results) => {
    if (err) {
      console.error('Error querying database: ' + err.stack);
      return;
    }
    
    // 遍历查询结果
    results.forEach(row => {
      const tid = row.sid;
      const plaintextPassword = row.spassword;
      
      // 使用 SHA-256 哈希算法加密密码
      const hashedPassword = crypto.createHash('sha256').update(plaintextPassword).digest('hex');
      
      // 更新数据库中的密码
      connection.query('UPDATE students SET spassword = ? WHERE sid = ?', [hashedPassword, tid], err => {
        if (err) {
          console.error(`Error updating password for user ${tid}: ` + err.stack);
        } else {
          console.log(`Password updated for user ${tid}`);
        }
      });
    });
    
    // 关闭数据库连接
    connection.end(err => {
      if (err) {
        console.error('Error closing database connection: ' + err.stack);
        return;
      }
      console.log('Database connection closed');
    });
  });
});
