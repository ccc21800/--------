const express = require('express');
const router = express.Router();
const mysql = require('mysql');
const config = require('./config');
const crypto = require('crypto-js');
const fs = require('fs');
const path = require('path');

const pool = mysql.createPool(config.database);

// 教师个人信息路由
router.get('/teacher/:tid/personal-info', (req, res) => {
  const tid = req.params.tid;

  try {
    // 从数据库获取教师信息
    pool.query('SELECT * FROM teachers WHERE tid = ?', [tid], (err, results) => {
      if (err) {
        console.error('Error executing database query:', err);
        return res.status(500).send('Internal Server Error');
      }

      if (results.length > 0) {
        const teacher = results[0];
        res.render('teacher_personal_info', { teacher });
      } else {
        res.status(404).send('Teacher not found');
      }
    });
  } catch (err) {
    console.error('Error in /teacher/:tid/personal-info route:', err);
    res.status(500).send('Internal Server Error');
  }
});
router.post('/teacher/:tid/change-password', (req, res) => {
  const tid = req.params.tid;
  const { currentPassword, newPassword } = req.body;

  // 首先验证当前密码是否正确
  pool.query('SELECT tpassword FROM teachers WHERE tid = ?', [tid], (err, results) => {
    if (err) {
      console.error('Error executing database query:', err);
      return res.status(500).send('Internal Server Error');
    }

    if (results.length > 0) {
      const storedPasswordHash = results[0].tpassword;

      // 比较当前密码哈希和存储的密码哈希
      const currentPasswordHash = crypto.SHA256(currentPassword).toString();
      if (currentPasswordHash === storedPasswordHash) {
        // 如果当前密码正确,则更新新密码
        const newPasswordHash = crypto.SHA256(newPassword).toString();
        pool.query('UPDATE teachers SET tpassword = ? WHERE tid = ?', [newPasswordHash, tid], (err, result) => {
          if (err) {
            console.error('Error executing database query:', err);
            return res.status(500).send('Internal Server Error');
          }

          res.redirect('/teacher/' + tid + '/personal-info');
        });
      } else {
        // 如果当前密码不正确,返回错误消息
        res.status(401).send('Invalid current password');
      }
    } else {
      res.status(404).send('Teacher not found');
    }
  });
});
// 商品管理路由
router.get('/product-management', (req, res) => {
  pool.query('SELECT * FROM commodities', (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Internal Server Error');
    }

    const products = results;
    res.render('product_management', { products });
  });
});

// 添加新商品路由
router.get('/product/add', (req, res) => {
  res.render('product_add');
});

router.post('/product/add', (req, res) => {
  const { coname, coimage, coprice, coamount, codetails } = req.body;
  pool.query('INSERT INTO commodities (coname, coimage, coprice, coamount, codetails) VALUES (?, ?, ?, ?, ?)', [coname, coimage, coprice, coamount, codetails], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Internal Server Error');
    }
    res.redirect('/product-management');
  });
});

// 编辑商品路由
router.get('/product/edit/:coname', (req, res) => {
  const coname = req.params.coname;
  pool.query('SELECT * FROM commodities WHERE coname = ?', [coname], (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Internal Server Error');
    }
    if (results.length > 0) {
      const product = results[0];
      res.render('product_edit', { product });
    } else {
      res.status(404).send('Product not found');
    }
  });
});

router.post('/product/edit/:coname', (req, res) => {
  const coname = req.params.coname;
  const { newConame, coimage, coprice, coamount } = req.body;
  pool.query('UPDATE commodities SET coname = ?, coimage = ?, coprice = ?, coamount = ? WHERE coname = ?', [newConame, coimage, coprice, coamount, coname], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Internal Server Error');
    }
    res.redirect('/product-management');
  });
});

// 删除商品路由
router.get('/product/delete/:coname', (req, res) => {
  const coname = req.params.coname;
  pool.query('DELETE FROM commodities WHERE coname = ?', [coname], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Internal Server Error');
    }
    res.redirect('/product-management');
  });
});

// 权限管理路由
// 获取学生权限列表
// 渲染权限管理视图
router.get('/permission-management', (req, res) => {
  res.render('permission_management');
});
router.get('/permissions', (req, res) => {
  pool.query('SELECT sid, sname, spower FROM students', (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Internal Server Error');
    }

    const studentPermissions = results;
    res.render('permission_management', { studentPermissions });
  });
});


router.post('/permissions/:sid', (req, res) => {
  const sid = req.params.sid;
  const { spower } = req.body;

  pool.query('UPDATE students SET spower = ? WHERE sid = ?', [spower, sid], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Internal Server Error');
    }

    res.sendStatus(200);
  });
});

// 学生管理路由
router.get('/student-management', (req, res) => {
  pool.query('SELECT * FROM students', (err, results) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Internal Server Error');
    }

    const students = results;
    res.render('student_management', { students });
  });
});

// 更新学生积分路由
router.post('/student/:sid/update-tokens', (req, res) => {
  const sid = req.params.sid;
  const tokens = parseInt(req.body.tokens);

  pool.query('UPDATE students SET stoken = stoken + ? WHERE sid = ?', [tokens, sid], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Internal Server Error');
    }

    res.sendStatus(200);
  });
});

router.get('/end', (req, res) => {
  const examDir = path.join(__dirname, 'exam');

  fs.readdir(examDir, (err, files) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Internal Server Error');
    }

    const zipFiles = files.filter(file => path.extname(file).toLowerCase() === '.zip');

    res.render('end', { zipFiles });
  });
});

module.exports = router;